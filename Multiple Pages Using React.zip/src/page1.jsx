import React from 'react';

export default function Page1() {
  return (
    <div className='App'>
      <h1>This is page 1</h1>
    </div>
  );
}