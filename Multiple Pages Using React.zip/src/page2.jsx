import React from 'react';

export default function Page2(props) {
  return (
    <div className='App'>
      <h1>This is page 2</h1>
    </div>
  );
}